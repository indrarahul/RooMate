package com.example.roomate.roomate;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;


public class MainActivity extends Activity {

    private final String DEVICE_ADDRESS="20:16:02:29:53:24";
    private final UUID PORT_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");//Serial Port Service ID
    private BluetoothDevice device;
    private BluetoothSocket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    Button connectButton, OnButton,OnButton2,OnButton3,OnButton4;
    TextView textView;

    boolean deviceConnect=false;
    byte buffer[];
    boolean stopThread;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connectButton = (Button) findViewById(R.id.buttonConnect);
        OnButton = (Button) findViewById(R.id.buttonOn);
        textView = (TextView) findViewById(R.id.textView);
        OnButton2 = (Button) findViewById(R.id.buttonOn2);
        OnButton3 = (Button) findViewById(R.id.buttonOn3);
        OnButton4 = (Button) findViewById(R.id.buttonOn4);
        UiEnabled(false);

       
    }

    public void UiEnabled(boolean bool)
    {
        connectButton.setEnabled(!bool);
        OnButton.setEnabled(bool);

        OnButton2.setEnabled(bool);
        textView.setEnabled(bool);

    }

    public boolean BTinitialize()
    {
        boolean found=false;
        BluetoothAdapter bluetoothAdapter=BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(),"Device doesn't Support Bluetooth",Toast.LENGTH_SHORT).show();
        }
        if(!bluetoothAdapter.isEnabled())
        {
            Intent enableAdapter = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableAdapter, 0);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
        if(bondedDevices.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Pair Device first",Toast.LENGTH_SHORT).show();
        }
        else
        {
            for (BluetoothDevice iterator : bondedDevices)
            {
                if(iterator.getAddress().equals(DEVICE_ADDRESS))
                {
                    device=iterator;
                    found=true;
                    break;
                }
            }
        }
        return found;
    }

    public boolean BTconnected()
    {
        boolean connected=true;
        try {
            socket = device.createRfcommSocketToServiceRecord(PORT_UUID);
            socket.connect();
        } catch (IOException e) {
            e.printStackTrace();
            connected=false;
        }
        if(connected)
        {
            try {
                outputStream=socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                inputStream=socket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }


        return connected;
    }

    public void onClickConnect(View view) {

            if (BTinitialize()) {
                if (BTconnected()) {
                    UiEnabled(true);
                    deviceConnect = true;
                    beginListenForData();
                    textView.setText("\nConnection Established!\n");
                }

            }

    }

    void beginListenForData()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = inputStream.available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            inputStream.read(rawBytes);
                            final String string=new String(rawBytes,"UTF-8");
                            handler.post(new Runnable() {
                                public void run()
                                {

                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }

    public void onClickOn(View view) {
        String string = "0";
        String string2 = "1";
        String status =(String) OnButton.getText();

        if(status.equals("OFF")) {
            try {

                outputStream.write(string.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            OnButton.setText("ON");

            OnButton.setTextColor(Color.parseColor("#01B216"));
        }

        else if(status.equals("ON")) {
            try {

                outputStream.write(string2.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            OnButton.setText("OFF");
            OnButton.setTextColor(Color.parseColor("#d30202"));

        }
        textView.setText("");
    }

   public void onClickOn2(View view) {
        String string = "4";
        String string2 = "3";
        String status = (String) OnButton2.getText();
       if(status.equals("OFF")) {
           try {

               outputStream.write(string.getBytes());
           } catch (IOException e) {
               e.printStackTrace();
           }
           OnButton2.setText("ON");
           OnButton2.setTextColor(Color.parseColor("#01B216"));
       }

       else if(status.equals("ON")) {
           try {

               outputStream.write(string2.getBytes());
           } catch (IOException e) {
               e.printStackTrace();
           }
           OnButton2.setText("OFF");
           OnButton2.setTextColor(Color.parseColor("#d30202"));

       }
       textView.setText("");

    }

    public void onClickOn3(View view) {
        String string = "6";
        String string2 = "5";
        String status = (String) OnButton3.getText();
        if(status.equals("OFF")) {
            try {

                outputStream.write(string.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            OnButton3.setText("ON");
            OnButton3.setTextColor(Color.parseColor("#01B216"));
        }

        else if(status.equals("ON")) {
            try {

                outputStream.write(string2.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            OnButton3.setText("OFF");
            OnButton3.setTextColor(Color.parseColor("#d30202"));

        }
        textView.setText("");
    }

    public void onClickOn4(View view) {
        String string = "8";
        String string2 = "7";
        String status = (String) OnButton4.getText();
        if(status.equals("OFF")) {
            try {

                outputStream.write(string.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            OnButton4.setText("ON");
            OnButton4.setTextColor(Color.parseColor("#01B216"));
        }

        else if(status.equals("ON")) {
            try {

                outputStream.write(string2.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            OnButton4.setText("OFF");
            OnButton4.setTextColor(Color.parseColor("#d30202"));

        }
        textView.setText("");

    }



}